//
//  ViewController.m
//  W2D5_KeyboardResizing
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textField;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomConstraint;

@property (nonatomic) CGFloat bottomConstraintConstant;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // so that we can set it back
    self.bottomConstraintConstant = self.bottomConstraint.constant;
    self.textField.delegate = self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)keyboardShow:(NSNotification *)notification {
    NSLog(@"%@", notification.userInfo);
    NSValue *value = notification.userInfo[UIKeyboardFrameBeginUserInfoKey];
    CGRect rect = [value CGRectValue];
    CGFloat keyboardHeight = rect.size.height;
    self.bottomConstraint.constant = keyboardHeight + self.bottomConstraintConstant;
}

- (void)keyboardHide:(NSNotification *)notification {
    NSLog(@"%@", notification.userInfo);
    self.bottomConstraint.constant = self.bottomConstraintConstant;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end

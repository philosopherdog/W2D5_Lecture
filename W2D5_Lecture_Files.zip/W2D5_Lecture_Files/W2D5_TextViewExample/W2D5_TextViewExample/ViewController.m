//
//  ViewController.m
//  W2D5_TextViewExample
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UILabel *label;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.textView.delegate = self;
    self.textView.text = @"";
    // label is for displaying the output
    self.label.text = @"";
    // numberOfLines = 0 makes the label multiline display
    self.label.numberOfLines = 0;
}


// ToDo

// 1. Output text to label as you type (Hint: Look at the UITextViewDelegate in the documentation and figure out which method can handle this

- (void)textViewDidChange:(UITextView *)textView {
    self.label.text = textView.text;
}

// 2. Control + Drag an action method from the submit button found in the storyboard

// 3. Inside the submit button's action method simply dismiss the keyboard.

// 4. Inside the submit button's action method remove any input text in the textView

- (IBAction)submitTapped:(UIButton *)sender {
    // 2, 3
    [self.textView resignFirstResponder];
    // 4
    self.textView.text = @"";
}
@end

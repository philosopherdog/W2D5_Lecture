//
//  ViewController.m
//  W2D5_TextFieldExample
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *label;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupTextField];
    [self addKeyboardObserver];
    // verbose way to add a tap gesture
    //    [self addTapGestureToView];
    
}

#pragma mark - Setup TextField

- (void)setupTextField {
    self.textField.placeholder = @"Type your name";
    self.textField.textColor = [UIColor redColor];
    self.textField.delegate = self;
    [self customizeKeyboard];
}

- (void)customizeKeyboard {
    // the protocol UITextInputTraits determines what keyboard is shown
    // You can customize the keyboard progrommatically or by setting it in IB
    // tracing the hierarchy of protocols from which UITextField and UITextView inherit the keyboardType  property is instructive.
    // both UITextField & UITextView conform to UITextInput protocol
    // UITextInput protocol inherits from UIKeyInput protocol
    // UIKeyInput protocol inherits from UITextInputTraits
    // It is in UITextInputTraits that we find the keyboardType property!
    self.textField.keyboardType = UIKeyboardTypeAlphabet;
}

#pragma mark - Handle Keyboard

- (void)addKeyboardObserver {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification *)notification {
    NSLog(@"%@",notification.userInfo);
    CGFloat kbHeight = [self heightForNotification:notification];
    [self adjustViewForKeyboardHeight:kbHeight];
}

// study this code carefully. Notice I am moving the textField's super view's bounds height!

- (CGFloat)heightForNotification:(NSNotification *)notification {
    NSValue *keyboardInfo = notification.userInfo[UIKeyboardFrameEndUserInfoKey];
    CGRect rect = [keyboardInfo CGRectValue];
    return rect.size.height;
}

- (void)adjustViewForKeyboardHeight:(CGFloat)height {
    CGRect viewBounds = self.view.bounds;
    viewBounds.origin.y += height;
    NSLog(@"%@", NSStringFromCGRect(viewBounds));
    self.view.bounds = viewBounds;
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSLog(@"%@", notification.userInfo);
    CGFloat kbHeight = [self heightForNotification:notification];
    [self adjustViewForKeyboardHeight:-kbHeight];
}

#pragma mark - Handle Gestures

// we intercept touchesBegan on the ViewController's view property to dismiss the keyboard
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([self.textField isFirstResponder]) {
        [self.textField resignFirstResponder];
    }
}

// we could have added a tap gesture like this if we needed more control over the type of gesture that triggers the action.
/*
- (void)addTapGestureToView {
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    [self.view addGestureRecognizer:tapGesture];
}

- (void)viewTapped:(UITapGestureRecognizer *)sender {
    if ([self.textField isFirstResponder]) {
        [self.textField resignFirstResponder];
    }
}
 */

#pragma mark - Delegate Methods

// This is a delegate method that fires when the keyboard's return key is tapped
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    // adds button when editing just to demonstrate intercepting this delegate
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithTitle:@"Stuff" style:UIBarButtonItemStylePlain target:self action:@selector(buttonTapped:)];
    self.navigationItem.rightBarButtonItem = button;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    // removes button when editing ends to demonstrate intercepting the didEndEditing delegate call
    self.navigationItem.rightBarButtonItem = nil;
}

// action method for the Stuff button
- (void)buttonTapped:(UIBarButtonItem*)sender {
    NSLog(@"%@ was tapped", sender.title);
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSString *str = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSLog(@"range: %@", NSStringFromRange(range));
    NSLog(@"%@", str);
    self.label.text = str;
    return YES;
}

#pragma mark - Clean Up

// You no longer need to remove observers as of iOS9 https://developer.apple.com/library/mac/releasenotes/Foundation/RN-Foundation/index.html#10_11NotificationCenter
// It's best practice to do it anyway

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



@end

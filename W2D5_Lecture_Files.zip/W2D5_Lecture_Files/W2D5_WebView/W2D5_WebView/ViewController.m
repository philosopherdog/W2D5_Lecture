//
//  ViewController.m
//  W2D5_WebView
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ViewController.h"
@import WebKit;

@interface ViewController ()
@property (nonatomic, strong) WKWebView *webView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    self.webView = [[WKWebView alloc] initWithFrame:frame];
    [self.view addSubview:self.webView];
    
    NSURL *url = [self constructURLWithSearchTerm:@"kitties"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
}

- (NSURL *)constructURLWithSearchTerm:(NSString *)searchTerm {
    NSURLComponents *components = [[NSURLComponents alloc] init];
    components.scheme = @"https";
    components.host = @"google.com";
    components.path = @"/search";
    NSURLQueryItem *queryItem = [NSURLQueryItem queryItemWithName:@"q" value:searchTerm];
    components.queryItems = @[queryItem];
    return components.URL;
}


@end

//
//  RandomNumberGenerator.h
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-09.
//  Copyright © 2016 steve. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RandomNumberGenerator : NSObject
+ (int)randomNumberTo:(int)to;
@end

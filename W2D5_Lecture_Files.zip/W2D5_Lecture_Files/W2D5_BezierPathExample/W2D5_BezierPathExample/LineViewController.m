//
//  LineViewController.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import "LineViewController.h"
#import "ChartData.h"
#import "LineChartView.h"

@interface LineViewController()
@property (weak, nonatomic) IBOutlet LineChartView *lineChartView;
@end

@implementation LineViewController

- (void)setChartData:(NSArray<ChartData *> *)chartData {
    NSLog(@"%@", chartData);
    _chartData = chartData;
}

- (void)viewDidLoad {
    self.lineChartView.chartData = self.chartData;
}
@end

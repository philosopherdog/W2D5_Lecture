//
//  CustomView.h
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-03-17.
//  Copyright © 2016 steve. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ChartData;

@interface BarChartView : UIView
- (void)randomize;
@property (nonatomic) NSArray<ChartData*>*chartBarArray;
@end

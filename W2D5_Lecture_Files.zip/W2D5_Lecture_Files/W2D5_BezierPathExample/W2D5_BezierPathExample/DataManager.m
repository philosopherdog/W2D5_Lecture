//
//  DataManager.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import "DataManager.h"
#import "ChartData.h"

#define kTotalNumberOfBars 10

@implementation DataManager

- (instancetype)init {
    if (self = [super init]) {
        [self createChartObjects];
    }
    return self;
}

- (void)createChartObjects {
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:kTotalNumberOfBars];
    for (NSInteger i = 0; i < kTotalNumberOfBars; ++i) {
        ChartData *chartBar = [ChartData new];
        [result addObject:chartBar];
    }
    self.dataArray = result;
}
@end

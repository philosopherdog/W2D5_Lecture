//
//  ViewController.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-03-17.
//  Copyright © 2016 steve. All rights reserved.
//

#import "BarViewController.h"
#import "BarChartView.h"
#import "DataManager.h"
#import "LineViewController.h"

@interface BarViewController ()
@property (weak, nonatomic) IBOutlet BarChartView *barChartView;
@property (nonatomic) DataManager *dataManager;
@end

@implementation BarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addBarButtons];
    self.dataManager = [DataManager new];
    self.barChartView.chartBarArray = self.dataManager.dataArray;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(chartWasTapped:) name:@"ChartValueNotification" object:nil];
}

#pragma mark - Button Actions

- (void)addBarButtons {
    UIBarButtonItem *randButton = [[UIBarButtonItem alloc] initWithTitle:@"Randomize" style:UIBarButtonItemStylePlain target:self action:@selector(randomize)];
    UIBarButtonItem *lineGraph = [[UIBarButtonItem alloc] initWithTitle:@"Line Graph" style:UIBarButtonItemStylePlain target:self action:@selector(lineGraph)];
    self.navigationItem.leftBarButtonItems = @[randButton];
    self.navigationItem.rightBarButtonItems = @[lineGraph];
}

- (void)randomize {
    [self.barChartView randomize];
    // the title will be used to display the value of the bar when we tap on it
    self.navigationItem.title = @"";
}

#pragma mark - Handle Segue With Line Graph Button Tapped

static NSString *segueID = @"LineViewController";

- (void)lineGraph {
    [self performSegueWithIdentifier:segueID sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:segueID]) {
        LineViewController *lineViewController = segue.destinationViewController;
        lineViewController.chartData = self.dataManager.dataArray;
    }
}

#pragma mark - Handle Chart Taps

- (void)chartWasTapped:(NSNotification *)notification {
    NSString *value = notification.userInfo[@"value"];
    self.navigationItem.title = value;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end

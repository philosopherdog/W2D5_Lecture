//
//  CustomView.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-03-17.
//  Copyright © 2016 steve. All rights reserved.
//

#import "BarChartView.h"
#import "ChartData.h"

static const CGFloat kDefaultSpacer = 20.0;
static const CGFloat kMaxBarValue = 10.0;

#define kNumberOfItems 10

@interface BarChartView()
// defaults
@property (nonatomic, readonly) CGFloat kViewHeight;
@property (nonatomic, readonly) CGFloat kViewWidth;
@property (nonatomic, readonly) CGFloat kItemWidth;
@property (nonatomic, readonly) CGFloat kGraphHeight;
@end


IB_DESIGNABLE @implementation BarChartView

// called from VC
- (void)randomize {
    for (ChartData *chartBar in self.chartBarArray) {
        [chartBar randomize];
    }
    // redraws the view
    [self setNeedsDisplay];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _kViewHeight = self.bounds.size.height;
    _kViewWidth = self.bounds.size.width;
    _kItemWidth = ((_kViewWidth - (kDefaultSpacer * 2)) / kNumberOfItems);
    _kGraphHeight = _kViewHeight - (kDefaultSpacer * 2);
    [self setNeedsDisplay];
}

#pragma mark - DrawRect

- (void)drawRect:(CGRect)rect {
    // [self createChartWithBezierPath];
    [self createChartWithCoreGraphics:UIGraphicsGetCurrentContext()];
}

#pragma mark - Drawing Using Core Graphics
- (void)createChartWithCoreGraphics:(CGContextRef)context {
    for (NSInteger i = 0; i < self.chartBarArray.count; ++i) {
        ChartData *chartBar = self.chartBarArray[i];
        CGFloat xPosition = [self barXPostionForItemAtIndex:i];
        CGFloat barHeight = [self barHeightForItemWithValue:chartBar.value];
        // make zeros a sliver
        barHeight = barHeight == 0.0 ? 2.0 : barHeight;
        
        CGRect rect = CGRectMake(xPosition, self.kViewHeight-kDefaultSpacer, self.kItemWidth, -barHeight);
        CGContextSetFillColorWithColor(context, chartBar.color.CGColor);
        CGContextFillRect(context, rect);
    }
}

#pragma mark - Drawing Using Bezier Path

- (void)createChartWithBezierPath {
    for (NSInteger i = 0; i < self.chartBarArray.count; ++i) {
        
        ChartData *chartBar = self.chartBarArray[i];
        CGFloat xPosition = [self barXPostionForItemAtIndex:i];
        CGFloat barHeight = [self barHeightForItemWithValue:chartBar.value];
        // make zeros a sliver
        barHeight = barHeight == 0.0 ? 2.0 : barHeight;
        
        CGRect rect = CGRectMake(xPosition, self.kViewHeight-kDefaultSpacer, self.kItemWidth, -barHeight);
        
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:rect];
        [chartBar.color setFill];
        [path fill];
    }
}

- (CGFloat)barHeightForItemWithValue:(NSInteger)value {
    return (self.kGraphHeight / kMaxBarValue) * value;
}

- (CGFloat)barXPostionForItemAtIndex:(NSInteger)index {
    return kDefaultSpacer + (self.kItemWidth * index);
}

#pragma mark - Handle Tapping Bars

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    [self showChartBarValueAtCGPoint:point];
    return nil;
}

- (void)showChartBarValueAtCGPoint:(CGPoint)point {
    NSInteger itemNum = [self indexForItemAtPoint:point];
    ChartData *bar = self.chartBarArray[itemNum];
    NSString *value = @(bar.value).stringValue;
    // notify VC and pass value
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ChartValueNotification" object:nil userInfo:@{@"value": value}];
}

- (NSInteger)indexForItemAtPoint:(CGPoint)point {
    CGFloat xPosition = point.x;
    CGFloat firstPosition = kDefaultSpacer + self.kItemWidth;
    if (xPosition <= firstPosition) {
        return 0;
    }
    return MIN((NSInteger)((xPosition - firstPosition)/self.kItemWidth)+1, 9);
}

@end


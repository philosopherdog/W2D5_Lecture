//
//  RandomNumberGenerator.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-09.
//  Copyright © 2016 steve. All rights reserved.
//

#import "RandomNumberGenerator.h"

@implementation RandomNumberGenerator
+ (int)randomNumberTo:(int)to {
    if (to <= 1) {
        return to;
    }
    return arc4random_uniform(to);
}
@end

//
//  AppDelegate.m
//  Responder_Example
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

//- (void)buttonTapped {
//    NSLog(@"%s", __PRETTY_FUNCTION__);
//}


@end

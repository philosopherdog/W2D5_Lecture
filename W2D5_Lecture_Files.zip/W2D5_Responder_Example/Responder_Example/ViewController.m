//
//  ViewController.m
//  Responder_Example
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // setup target action where target is nil
    
    SEL selector = NSSelectorFromString(@"buttonTapped");
    
    
    [self.button addTarget:nil action:selector forControlEvents:UIControlEventTouchUpInside];

}

//- (void)buttonTapped {
//    NSLog(@"%s", __PRETTY_FUNCTION__);
//}



@end

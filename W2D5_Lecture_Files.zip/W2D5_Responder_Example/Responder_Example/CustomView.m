//
//  CustomView.m
//  Responder_Example
//
//  Created by steve on 2016-03-15.
//  Copyright © 2016 steve. All rights reserved.
//

#import "CustomView.h"

@implementation CustomView

//- (void)buttonTapped {
//    NSLog(@"%s", __PRETTY_FUNCTION__);
//}
@end

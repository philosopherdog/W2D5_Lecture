//
//  UIColor+RandomColor.h
//  Debugging
//
//  Created by steve on 2016-02-08.
//  Copyright © 2016 steve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (RandomColor)
+ (UIColor *)randomColor;
@end

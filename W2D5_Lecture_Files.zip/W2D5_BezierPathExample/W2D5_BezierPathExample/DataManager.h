//
//  DataManager.h
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ChartData;

@interface DataManager : NSObject
@property (nonatomic) NSArray *dataArray;
@end

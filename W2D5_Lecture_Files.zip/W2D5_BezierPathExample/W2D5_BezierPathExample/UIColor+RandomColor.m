//
//  UIColor+RandomColor.m
//  Debugging
//
//  Created by steve on 2016-02-08.
//  Copyright © 2016 steve. All rights reserved.
//

#import "UIColor+RandomColor.h"

@implementation UIColor (RandomColor)

+ (UIColor *)randomColor
{
    return [[UIColor alloc] initWithRed:arc4random()%256/256.0 green:arc4random()%256/256.0 blue:arc4random()%256/256.0 alpha:1.0];
}

@end

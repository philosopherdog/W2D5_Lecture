//
//  LineChartView.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import "LineChartView.h"
#import "ChartData.h"

const CGFloat kDefaultSpacer = 20.0;

#define kNumberOfItems 10

@interface LineChartView()
@property (nonatomic, readonly) CGFloat kViewHeight;
@property (nonatomic, readonly) CGFloat kViewWidth;
@property (nonatomic, readonly) CGFloat kItemWidth;
@property (nonatomic, readonly) CGFloat kGraphHeight;
@end

@implementation LineChartView

- (void)layoutSubviews {
    [super layoutSubviews];
    _kViewHeight = self.bounds.size.height;
    _kViewWidth = self.bounds.size.width;
    _kItemWidth = ((_kViewWidth - (kDefaultSpacer * 2)) / kNumberOfItems);
    _kGraphHeight = _kViewHeight - (kDefaultSpacer * 2);
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
    [self drawLineUsingBezierPath];
}

// UIBezierPath drawing

#define kOvalWidthHeight 20

- (void)drawLineUsingBezierPath {
    CGPoint previousPoint = CGPointZero;
    for (NSInteger i = 0; i < self.chartData.count; ++i) {
        ChartData *chartData = self.chartData[i];
        UIBezierPath *line = [UIBezierPath bezierPath];
        CGFloat yPosition = [self yPositionForItemWithValue:chartData.value];
        CGFloat xPostion = [self xPostionForItemAtIndex:i];
        CGPoint point = CGPointMake(xPostion, yPosition);
        [chartData.color setStroke];
        [line setLineCapStyle:kCGLineCapRound];
        line.lineWidth = 4.0;
        UIBezierPath *dot = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(xPostion-kOvalWidthHeight/2, yPosition-kOvalWidthHeight/2, kOvalWidthHeight, kOvalWidthHeight)];
        [chartData.color setFill];
        if (i == 0) {
            previousPoint = point;
            [line moveToPoint:point];
            [line addLineToPoint:point];
            [dot fill];
            [line stroke];
            continue;
        }
        [line moveToPoint:previousPoint];
        [line addLineToPoint:point];
        previousPoint = point;
        [dot fill];
        [line stroke];
    }
}

- (CGFloat)yPositionForItemWithValue:(NSInteger)value {
    CGFloat heightPerItem = (self.kGraphHeight/kNumberOfItems);
    return (self.kGraphHeight - (heightPerItem * value));
}

- (CGFloat)xPostionForItemAtIndex:(NSInteger)index {
    if (index == 0) {
        return (kDefaultSpacer + (self.kItemWidth/2));
    }
    return ((self.kItemWidth * index) + (kDefaultSpacer + self.kItemWidth/2));
}

@end

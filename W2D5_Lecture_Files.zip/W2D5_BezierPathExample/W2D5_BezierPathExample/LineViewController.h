//
//  LineViewController.h
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ChartData;

@interface LineViewController : UIViewController
@property (nonatomic, copy) NSArray<ChartData*>*chartData;
@end

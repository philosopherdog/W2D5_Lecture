//
//  LineChartView.h
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ChartData;

IB_DESIGNABLE @interface LineChartView : UIView
@property (nonatomic, copy) NSArray<ChartData*>* chartData;
@end

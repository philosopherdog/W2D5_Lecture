//
//  ChartBar.h
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

/*
 
 Model Class
 
 */

@import UIKit;

@interface ChartData : NSObject
@property (nonatomic, strong) UIColor *color;
@property (nonatomic)NSUInteger value;
- (void)randomize;
@end

//
//  ChartBar.m
//  W2D5_BezierPathExample
//
//  Created by steve on 2016-05-10.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ChartData.h"
#import "UIColor+RandomColor.h"
#import "RandomNumberGenerator.h"

@implementation ChartData

- (instancetype)init {
    if (self = [super init]) {
        [self randomize];
    }
    return self;
}

- (void)randomize {
    _value = [RandomNumberGenerator randomNumberTo:10];
    _color = [UIColor randomColor];
}
@end
